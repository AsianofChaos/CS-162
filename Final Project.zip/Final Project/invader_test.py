class Invader:
    '''asdfsdfs'''

    def __init__(self, new_id=-1, new_x0=0, new_y0=0, new_x1=10, new_y1=10, new_outline="black", new_fill="white", ):
        
        self.id = new_id
        self.x0 = new_x0
        self.y0 = new_y0
        self.x1 = new_x1
        self.y1 = new_y1
        self.outline = new_outline
        self.fill = new_fill

        