class Defender:
    def __init__(self, id):
        self.id = id
        self.x0 = 0
        self.x1 = 0
        self.y0 = 0 
        self.y1 = 0



